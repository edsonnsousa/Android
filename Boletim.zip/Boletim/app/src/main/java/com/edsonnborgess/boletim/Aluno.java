package com.edsonnborgess.boletim;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Edson on 15/02/2018.
 */

public class Aluno extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aluno);
}
}
