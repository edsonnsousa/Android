package com.edsonnborgess.boletim;

/**
 * Created by Edson on 15/02/2018.
 */

public class Horario {
}
